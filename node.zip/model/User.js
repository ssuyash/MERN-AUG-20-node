const mongoose = require('mongoose')   


let UserSchema = mongoose.Schema({
    name:String,
    phone:String,
    age:Number,
    isMarried:Boolean    
})

module.exports = mongoose.model('user', UserSchema)