const express = require('express')
const app = express()
const bodyParser = require('body-parser')
const UserModel = require('./model/User')
const mongoose = require('mongoose')


mongoose.connect("mongodb://localhost:27017/priyanka", {
    useNewUrlParser: true,        
  }).catch(err => console.log(err.reason));



app.use(bodyParser.json({ extended: false }))
app.use(bodyParser.urlencoded({ extended: false }))

app.post('/user', (req, res)=>{
    let {name, phone, age, married} = req.body
    let userobj = {
        name,
        phone, 
        age,
        isMarried:married
    }
    let user = new UserModel(userobj)
    user.save().then(result=>{
        console.log(result)
        res.send({msg:"OK"})

    }).catch(err=>{
        console.log(err)
        res.send({msg:"ERR"})
    })

})


app.get('/user', (req, res)=>{
    UserModel.find({}).then(result=>{
        res.send({data:result})
    }).catch(err=>{
        res.send({msg:"Err"})
    })
})





//app.Method("endpoint", handlerfunction)



app.listen(8083, ()=>{
    console.log("server started")
})






























































//  const http = require('http')

//  let server = http.createServer((req, res)=>{
//     let {method, url} = req    
//     console.log(method, url)

//     if(method == "GET" && url == "/about"){
//         res.end("about api")
//     }else  if(method == "GET" && url == "/"){
//         res.end("home api")
//     }else{
//         res.end("page not found")  
//     }

    
//  })

//  server.listen(2021, ()=>{
//      console.log("server is started")
//  })


